Place SR101Fix.exe and SR101Check.csv in a folder with your xxxx_LG.csv file.

Populate the SR101Check.csv with the intended output data in the below format (feel free to overwrite headings, which were added for instruction only):

NSG Ref, Export_Start_X, Export_Start_Y, Export_End_X, Export_End_Y, Amended_Start_X, Amended_Start_Y, Amended_End_X, Amended_End_Y
xxxxxxxx, xxxxxx.xx,      xxxxxx.xx,      xxxxxx.xx,     xxxxxx.xx,     xxxxxx.xx,       xxxxxx.xx,      xxxxxx.xx,     xxxxxx.xx       

Do not leave blank lines and double check that the Amended coordinates are correct (these should be the ESU start and end points), any blank spaces in the amended coordinates will result in the row being skipped.

Once you have amended the SR101Check.csv file double click SR101Fix.exe and enter your LA code when prompted, this will amend the records matching with the NSG reference and Export Start and End X and Y, if any of these are incorrect the row will be skipped.

Once the program is complete it will inform you how many records have been amended and you can upload your xxxx_LG.csv file as normal.
